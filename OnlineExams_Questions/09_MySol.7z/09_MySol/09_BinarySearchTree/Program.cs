﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
InventoryDataService inventory = new InventoryDataService(10);
inventory.AddSupply(2, 50);
inventory.AddDemand(3, 25);
inventory.AddDemand(2, 30);
inventory.DisplayInventory();
