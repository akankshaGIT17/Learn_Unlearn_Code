public class CurrentInventory{
    public CurrentInventory(int size)
    {
        CreateInventoryDataData(size);
    }
    public Dictionary<int, Inventory> InventoryData { get; set; } = new Dictionary<int, Inventory>();
    public double size { get; set; }

    public void CreateInventoryDataData(double value)
    {
        for (int i = 0; i <= value; i++)
        {
            Inventory inventory = new Inventory(0);
            inventory.Supply = new Inventory(0);
            inventory.Demand = new Inventory(0);
            InventoryData.Add(i, inventory);

        }
        size = value;
    }
}

 