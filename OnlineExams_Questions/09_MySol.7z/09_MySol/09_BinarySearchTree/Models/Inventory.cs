public class Inventory
{
    public double Value;
    public Inventory Supply;
    public Inventory Demand;
    public Inventory(double val)
    {
        Value = val;
    }
    public double TraverseInventory(Inventory inventory)
    {
        if (inventory != null)
        {
            TraverseInventory(inventory.Supply);
            TraverseInventory(inventory.Demand);
            return (inventory.Value);
        }
        return 0;
    }

}
