public interface IInventoryDataService{
    public void AddSupply(int bucket, double supply);
    public void AddDemand(int bucket, double demand);
    public void GetInventory(int bucket);
}