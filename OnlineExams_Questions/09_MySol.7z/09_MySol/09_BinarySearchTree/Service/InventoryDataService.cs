public class InventoryDataService : IInventoryDataService
{
    CurrentInventory inventoryModel;
    AddUpdateInventory setInventory;
    int _size;
    public InventoryDataService(int size)
    {
        inventoryModel = new CurrentInventory(size);
        setInventory = new AddUpdateInventory();
        _size = size;
    }
    public void AddSupply(int bucket, double supply)
    {
        if (inventoryModel.InventoryData.ContainsKey(bucket))
        {
            inventoryModel.InventoryData[bucket].Supply = new Inventory(supply);
        }
        setInventory.Calculate(bucket, _size, inventoryModel);
    }

    public void AddDemand(int bucket, double demand)
    {
        if (inventoryModel.InventoryData.ContainsKey(bucket))
        {
            inventoryModel.InventoryData[bucket].Demand = new Inventory(demand);
        }
        setInventory.Calculate(bucket, _size, inventoryModel);
    }

    public void GetInventory(int bucket)
    {
        Console.WriteLine(inventoryModel.InventoryData[bucket].Value);
    }

    public void DisplayInventory()
    {
        foreach (var iv in inventoryModel.InventoryData)
        {
            Console.WriteLine(Environment.NewLine + iv.Key + " - ");
           setInventory.ShowCalculation(iv.Value);
        }
    }

    
}
