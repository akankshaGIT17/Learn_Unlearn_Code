public class AddUpdateInventory
{
    public void Calculate(int bucket, int size, CurrentInventory inventory)
    {
        if (bucket > size)
        {
            return;
        }
        double InventoryCalc = 0;
        int prevbucket = bucket;
        if (bucket - 1 >= 0)
        {
            prevbucket = bucket - 1;
        }
        if (inventory.InventoryData[bucket].Supply.Value > 0 || inventory.InventoryData[bucket].Demand.Value > 0)
        {
            InventoryCalc = inventory.InventoryData[prevbucket].Value + (inventory.InventoryData[bucket].Supply.Value - inventory.InventoryData[bucket].Demand.Value);
        }
        else
        {
            InventoryCalc = inventory.InventoryData[prevbucket].Value;
        }

        inventory.InventoryData[bucket].Value = InventoryCalc;
        bucket = bucket + 1;
        Calculate(bucket, size, inventory);
    }
    public void ShowCalculation(Inventory n)
    {
        if (n != null)
        {
            ShowCalculation(n.Supply);

            ShowCalculation(n.Demand);
            Console.Write(" " + n.Value);
        }
    }
}

public class Semaphore
{
    private object _mutex = new object();
    private int _currAvail;
    public Semaphore(int capacity)
    {
        _currAvail = capacity;
    }
    public void Wait()
    {
        lock (_mutex)
        {
            if (_currAvail == 0) Monitor.Wait(_mutex);
            _currAvail--;
        }
    }
    public void Signal()
    {
        lock (_mutex)
        {
            _currAvail++;
            Monitor.Pulse(_mutex);
        }
    }
}