﻿namespace SaaSInventory.Models
{
    public class SoftwareAdvice:BaseProperties
    {
        public List<string> Categories { get; set; }
        public string Title { get; set; }
    }
}
