﻿namespace SaaSInventory.Models
{
    public class BaseProperties
    {
       public string Twitter { get;set; }
    }
}
