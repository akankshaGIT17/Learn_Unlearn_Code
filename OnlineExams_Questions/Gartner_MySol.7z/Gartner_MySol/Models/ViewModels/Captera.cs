﻿namespace SaaSInventory.Models
{
    public class Captera:BaseProperties
    {
        public string Tags { get; set; }
        public string Name { get; set; }
    }
}
