﻿namespace sample
{
    public class Class1
    {

    }
}