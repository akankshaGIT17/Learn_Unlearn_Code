using DataAccess;
using Moq;
using NUnit.Framework;
using SaaSInventory.Models;
using SaaSInventory.Service;
using System;
using business = BusinessLogic.Contratcts;
namespace SaaSInventoryTest
{
    public class Tests
    {
        private Mock<IFileOperations> _mockOperations;
        private Mock<IRepository<Captera>> _mockCaptera;
        private Mock<IRepository<SoftwareAdvice>> _mockSoftwareAdvices;
        private IFileOperations fileOperations;
        [SetUp]
        public void Setup()
        {
            _mockOperations = new Mock<IFileOperations>();
            _mockCaptera = new Mock<IRepository<Captera>>();
            _mockSoftwareAdvices = new Mock<IRepository<SoftwareAdvice>>();
            var serviceProvider = new Mock<business.IServiceProvider>();
            fileOperations = new FileOperations(serviceProvider.Object, _mockCaptera.Object, _mockSoftwareAdvices.Object);
        }

        [Test]
        public void Test1()
        {
            var data = fileOperations.GetFileDetails(@"C:\Projies\Gartner\SaaSInventory\SaaSInventory\feed-productsC:\Projies\Gartner\SaaSInventory\SaaSInventory\feed-products\softwareadvice.json");
            Assert.NotNull(data);
        }
    }
}