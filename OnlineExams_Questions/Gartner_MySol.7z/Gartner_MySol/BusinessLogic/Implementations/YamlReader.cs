﻿using BusinessLogic.Contratcts;
using YamlDotNet.Serialization.NamingConventions;

namespace SaaSInventory.BusinessLogic
{
    public class YamlReader : IYamlReader
    {
        public T Reader<T>(string path)
        {
            string stream = FileReader(path);
            var deserializer = new YamlDotNet.Serialization.DeserializerBuilder().WithNamingConvention(CamelCaseNamingConvention.Instance).Build();
            var yaml = deserializer.Deserialize<T>(File.ReadAllText(stream));

            return yaml;
            //using (var reader = new StreamReader(filepath))
            //{
            //    // Load the stream
            //    var yaml = new YamlStream();
            //    yaml.Load(reader);
            //    // the rest
            //}
        }

        private string FileReader(string path)
        {
            string completeYaml = File.ReadAllText(path);
            return completeYaml;
        }

    }
}
