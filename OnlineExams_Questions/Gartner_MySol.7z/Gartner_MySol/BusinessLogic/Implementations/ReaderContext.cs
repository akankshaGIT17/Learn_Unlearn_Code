﻿namespace SaaSInventory.BusinessLogic
{
    internal class ReaderContext
    {
        private readonly IReaderContext readerContext;
        public ReaderContext(IReaderContext _readerContext)
        {
            readerContext = _readerContext;
        }

        public void Read<T>(string Path)
        {
            readerContext.Reader<T>(Path);
        }
    }
}
