﻿using BusinessLogic.Contratcts;
using Newtonsoft.Json;

namespace SaaSInventory.BusinessLogic
{
    public class JSONReader : IJsonReader
    {
        public T Reader<T>(string path)
        {
            JsonSerializer serializer = new JsonSerializer();
            var reader = this.StreamReader(path);
            return serializer.Deserialize<T>(reader);
        }
      
        private JsonTextReader StreamReader(string path)
        {
            using (StreamReader r = new StreamReader(path))
            {
                JsonTextReader reader = new JsonTextReader(r);
                //string json = r.ReadToEnd();
                return reader;
            }
        }

    }
}
