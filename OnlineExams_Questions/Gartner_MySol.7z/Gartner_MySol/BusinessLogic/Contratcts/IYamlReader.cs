﻿using SaaSInventory.BusinessLogic;

namespace BusinessLogic.Contratcts
{
    public interface IYamlReader:IReaderContext
    {
    }
}
