﻿using SaaSInventory.BusinessLogic;

namespace BusinessLogic.Contratcts
{
    public interface IJsonReader:IReaderContext
    {
    }
}
