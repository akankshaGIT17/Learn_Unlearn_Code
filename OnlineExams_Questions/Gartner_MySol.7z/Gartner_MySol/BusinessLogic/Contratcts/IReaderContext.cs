﻿namespace SaaSInventory.BusinessLogic
{
    public interface IReaderContext
    {
        public T Reader<T>(string path);

    }
}
