﻿namespace Utilities
{
    public static class Constants
    {
        public const string Json = "json";
        public const string yaml = "yaml";
        public const string JsonPath = ".json";
        public const string YamlPath = ".yaml";
    }
}
