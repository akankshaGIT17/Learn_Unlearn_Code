﻿// See https://aka.ms/new-console-template for more information
using BusinessLogic.Contratcts;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SaaSInventory.BusinessLogic;
using SaaSInventory.Service;

namespace Inventory
{
    class Program
    {
        private static System.IServiceProvider serviceProvider;
        private readonly IFileOperations fileOperations;
        public static void Main(string[] args)
        {
            ConfigureServices();
            UserInput();
           // CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            
            return Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((hostingContext, config) =>
                {
                    //services.AddTransient<ITransientOperation, DefaultOperation>()
                    //.AddScoped<IScopedOperation, DefaultOperation>()
                    config.SetBasePath(Directory.GetCurrentDirectory());
                    config.AddJsonFile("AppConfig/appsettings.json", optional: false, reloadOnChange: true);
                    config.AddJsonFile($"AppConfig/appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development"}.json", optional: true, reloadOnChange: true);
                });
                
        }
        public static void ConfigureServices()
        {
            var services = new ServiceCollection();
            services.AddScoped<IJsonReader, JSONReader>();
            services.AddScoped<BusinessLogic.Contratcts.IServiceProvider, BusinessLogic.ServiceProvider>();
            services.AddScoped<IYamlReader, YamlReader>();
            services.AddScoped<IFileOperations, FileOperations>();
            services.AddScoped(typeof(IRepository<>), typeof(SQLRepository<>));
            serviceProvider = services.BuildServiceProvider();
          
        }

        public static void UserInput()
        {
            var services = new ServiceCollection();
            Console.WriteLine("Enter folder path");
            var path = Console.ReadLine();
            var files = services.BuildServiceProvider().GetService<IFileOperations>();
            var output  = files.GetFileDetails(path);
            Print(output);

        }
        public static void Print(List<string> Data)
        {
            foreach (var file in Data)
            {
                Console.WriteLine(file);
            }
        }
    }
}