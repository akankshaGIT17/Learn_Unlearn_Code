﻿using SaaSInventory.BusinessLogic;
using Utilities;

namespace BusinessLogic.Contratcts
{
    public interface IServiceProvider
    {
        IReaderContext GetService(Formats step);
    }
}
