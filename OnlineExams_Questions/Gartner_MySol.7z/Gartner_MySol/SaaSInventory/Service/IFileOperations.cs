﻿namespace SaaSInventory.Service
{
    public interface IFileOperations
    {
        public List<string> GetFileDetails(string path);
    }
}
