﻿using business= BusinessLogic.Contratcts;
using Utilities;
using BusinessLogic.Contratcts;
using Microsoft.Extensions.DependencyInjection;
using SaaSInventory.BusinessLogic;
using DataAccess;

namespace BusinessLogic
{
    public class ServiceProvider: business.IServiceProvider
    {
        private readonly System.IServiceProvider serviceProvider;
        public ServiceProvider(System.IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }
        public IReaderContext GetService(Formats step)
        {
            switch (step)
            {
                case Formats.JSON:
                   return serviceProvider.GetRequiredService<IJsonReader>();
                case Formats.YAML:
                    return serviceProvider.GetRequiredService<IYamlReader>();
                default:
                    return null;
            }
        }

     
    }
}
