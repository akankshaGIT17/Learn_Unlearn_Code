﻿using DataAccess;
using SaaSInventory.BusinessLogic;
using SaaSInventory.Models;
using Utilities;
using business = BusinessLogic.Contratcts;

namespace SaaSInventory.Service
{
    public class FileOperations : IFileOperations
    {
        private readonly business.IServiceProvider _serviceProvider;
        private readonly IRepository<Captera> _CapteraRepository;
        private readonly IRepository<SoftwareAdvice> _SoftwareAdviceRepository;
        public FileOperations(business.IServiceProvider serviceProvider, IRepository<Captera> CapteraRepository, IRepository<SoftwareAdvice> SoftwareAdviceRepository)
        {
            _serviceProvider = serviceProvider;
            _CapteraRepository = CapteraRepository;
            _SoftwareAdviceRepository = SoftwareAdviceRepository;
        }
        public List<string> GetFileDetails(string path)
        {
            var fileData = ReadFilesWithExtentionFromPath(path);
            var fileOutput = PerformFileOperations(fileData);
            return fileOutput;
        }

        private bool UploadJsonToDb(SoftwareAdvice jsonData)
        {
         return   _SoftwareAdviceRepository.Insert(jsonData);
        }
        
        private bool UploadYamlToDb(Captera yamlData)
        {
          return  _CapteraRepository.Insert(yamlData);
        }

        private dynamic ReadFilesWithExtentionFromPath(string path)
        {
            DirectoryInfo dir = new DirectoryInfo(path);
            var ext = Path.GetExtension(path);
            return ReadFiles(ext, path);
        }
        private List<string> GenerateOutputJson(List<SoftwareAdvice> ListData)
        {
            List<string> outputJson = new List<string>();
            foreach (var data in ListData)
            {
                outputJson.Add($"Name: {data.Title}; Categories: {data.Categories}; Twitter: @{data.Twitter}");
            }
            return outputJson;
        }
        
        private List<string> GenerateOutputYaml(List<Captera> ListData)
        {
            List<string> outputJson = new List<string>();
            foreach (var data in ListData)
            {
                outputJson.Add($"Name: {data.Name}; Categories: {data.Tags}; Twitter: @{data.Twitter}");
            }
            return outputJson;
        }
        private List<string> PerformFileOperations(dynamic data)
        {
            if(data is List<Captera>)
            {
                UploadYamlToDb((Captera)data[0]);
                return GenerateOutputYaml(data);
            }
            if(data is List<SoftwareAdvice>)
            {
                UploadJsonToDb((SoftwareAdvice)data[0]);
                return GenerateOutputJson(data);
            }
            return null;
        }
        private dynamic ReadFiles(string Extention, string Path)
        {
            dynamic service;
            dynamic data;
            switch (Extention)
            {
                case Constants.JsonPath:
                   service =  _serviceProvider.GetService(Formats.JSON);
                   data =  service.Reader<List<SoftwareAdvice>>(Path);
                    return data;
                case Constants.YamlPath:
                    service = _serviceProvider.GetService(Formats.YAML);
                    data = service.Reader<List<Captera>>(Path);
                    return data;
            }
            return null;
           
        }

    }
}
