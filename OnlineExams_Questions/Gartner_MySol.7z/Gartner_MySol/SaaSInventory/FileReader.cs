﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities;

namespace SaaSInventory
{
    internal class FileReader
    {
        public void GetAllFiles(string path)
        {
           var filesSetJson =  Directory.GetFiles(path, Constants.Json);
           var filesSetYaml =  Directory.GetFiles(path, Constants.yaml);
        }
    }
}
