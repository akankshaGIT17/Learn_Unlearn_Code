﻿using System.Linq.Expressions;

namespace DataAccess
{
    public class SQLRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        public void Delete(TEntity entityToDelete)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<TEntity> Get(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = "")
        {
           return new List<TEntity> { };
        }

        public bool Insert(TEntity entity)
        {
            if (entity == null)
                return false;
            else
                return true;
        }

        public void Update(TEntity entityToUpdate)
        {
            throw new NotImplementedException();
        }
    }
}
  
